package com.quantumatom.portal;

import com.quantumatom.QuantumAtomMod;
import com.quantumatom.dimension.QuantumRealmDimension;
import com.quantumatom.dimension.QuantumRealmDimension.ScaleLayer;
import com.quantumatom.entity.AtomEntity;
import com.quantumatom.network.ZoomEffectPayload;
import com.quantumatom.scale.ScaleManager;
import com.quantumatom.science.AtomElement;
import com.quantumatom.science.BlockChemistryMapper;
import com.quantumatom.science.BlockChemistryMapper.SyncedBlockContext;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import qouteall.imm_ptl.core.ScaleUtils;
import qouteall.imm_ptl.core.api.PortalAPI;
import qouteall.imm_ptl.core.chunk_loading.ChunkLoader;
import qouteall.imm_ptl.core.teleportation.ServerTeleportationManager;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Orchestrates seamless, zero-loading-screen multi-dimension transitions driven directly by
 * shrinking and growing across the 4-tier subatomic scale hierarchy:
 * {@code Overworld (10^0 m) <-> Atomic Realm (10^-10 m) <-> Nuclear Realm (10^-15 m) <-> Quark Realm (10^-18 m)}.
 * <p>
 * Uses Immersive Portals v6.0.6's {@link PortalAPI#addChunkLoaderForPlayer(class_3222, ChunkLoader)}
 * to stream destination chunks and entities to the client during the cinematic windup ticks,
 * followed by {@link ServerTeleportationManager#forceTeleportPlayer(class_3222, class_5321, class_243)}
 * at the transition apex (tick 11 of 18) for a completely seamless dimension swap with zero loading screen.
 */
public final class QuantumPortalManager {
	/** Total duration of each cinematic shrink/grow dimension transition (0.9 seconds). */
	public static final int TRANSITION_DURATION_TICKS = 18;

	/** Tick at which the destination layer is populated so entities stream to the client pre-swap. */
	public static final int POPULATE_TICK = 8;

	/** Tick at which the seamless Immersive Portals dimension teleport fires (apex of FOV warp & flash). */
	public static final int SWAP_TICK = 11;

	/** Default vertical anchor inside all three void subatomic dimensions (min_y = -64, height = 384). */
	public static final double SUBATOMIC_ANCHOR_Y = 128.0;

	/** Chunk radius streamed to the client via Immersive Portals' ChunkLoader ahead of the swap. */
	private static final int PRELOAD_CHUNK_RADIUS = 3;

	/**
	 * Per-player journey stack preserving exact return coordinates, gaze angles, synchronized
	 * Overworld block chemistry, selected element, and selected nucleon type across all 4 tiers.
	 */
	public static final class QuantumJourneyState {
		public class_5321<class_1937> macroDimension = class_1937.field_25179;
		public class_243 macroReturnPos;
		public float macroYRot;
		public float macroXRot;
		public class_2338 anchorBlockPos;
		public String syncedBlockName = "";
		public String syncedChemicalFormula = "";
		public AtomElement primaryMacroElement = AtomElement.CARBON;

		public class_243 atomicReturnPos;
		public float atomicYRot;
		public float atomicXRot;
		public AtomElement selectedElement = AtomElement.CARBON;

		public class_243 nuclearReturnPos;
		public float nuclearYRot;
		public float nuclearXRot;
		public boolean selectedIsProton = true;
	}

	private static final class ShrinkTransition {
		final boolean shrinkingIn;
		final ScaleLayer fromLayer;
		final ScaleLayer targetLayer;
		final class_5321<class_1937> destDimension;
		final class_243 destPos;
		final float destYRot;
		final float destXRot;
		final double startScale;
		final ChunkLoader preloader;

		// Context used to populate destination dimension right before the seamless swap
		final class_5321<class_1937> macroSourceDim;
		final class_2338 anchorBlockPos;
		final AtomElement targetElement;
		final boolean targetIsProton;
		final String sourceLabel;
		final class_243 lookForward;

		int elapsedTicks = 0;
		boolean populated = false;
		boolean swapped = false;

		ShrinkTransition(
				boolean shrinkingIn,
				ScaleLayer fromLayer,
				ScaleLayer targetLayer,
				class_5321<class_1937> destDimension,
				class_243 destPos,
				float destYRot,
				float destXRot,
				double startScale,
				ChunkLoader preloader,
				class_5321<class_1937> macroSourceDim,
				class_2338 anchorBlockPos,
				AtomElement targetElement,
				boolean targetIsProton,
				String sourceLabel,
				class_243 lookForward
		) {
			this.shrinkingIn = shrinkingIn;
			this.fromLayer = fromLayer;
			this.targetLayer = targetLayer;
			this.destDimension = destDimension;
			this.destPos = destPos;
			this.destYRot = destYRot;
			this.destXRot = destXRot;
			this.startScale = startScale;
			this.preloader = preloader;
			this.macroSourceDim = macroSourceDim;
			this.anchorBlockPos = anchorBlockPos;
			this.targetElement = targetElement;
			this.targetIsProton = targetIsProton;
			this.sourceLabel = sourceLabel;
			this.lookForward = lookForward;
		}
	}

	private static final Map<UUID, QuantumJourneyState> JOURNEY_STATES = new ConcurrentHashMap<>();
	private static final Map<UUID, ShrinkTransition> ACTIVE_TRANSITIONS = new ConcurrentHashMap<>();

	private QuantumPortalManager() {
	}

	public static boolean isTransitioning(UUID playerId) {
		return playerId != null && ACTIVE_TRANSITIONS.containsKey(playerId);
	}

	public static QuantumJourneyState getJourneyState(UUID playerId) {
		return JOURNEY_STATES.computeIfAbsent(playerId, id -> new QuantumJourneyState());
	}

	/**
	 * Starts a cinematic 18-tick shrinking dive into the next deeper subatomic dimension:
	 * {@code OVERWORLD -> ATOMIC -> NUCLEAR -> QUARK}.
	 */
	public static boolean startDiveTransition(class_3222 player) {
		MinecraftServer server = player.method_5682();
		if (server == null) {
			return false;
		}
		UUID playerId = player.method_5667();
		if (ACTIVE_TRANSITIONS.containsKey(playerId)) {
			return false;
		}

		class_3218 sourceLevel = player.method_51469();
		ScaleLayer currentLayer = QuantumRealmDimension.getLayer(sourceLevel);
		ScaleLayer targetLayer = currentLayer.deeper();
		if (currentLayer == ScaleLayer.QUARK || targetLayer == null || targetLayer == currentLayer) {
			player.method_7353(
					class_2561.method_43470("Fundamental Limit Reached — Quarks & Gluons are elementary particles (Standard Model, 10^-18 m)!"),
					true
			);
			return false;
		}

		class_3218 destLevel = QuantumRealmDimension.getLevelForLayer(server, targetLayer);
		if (destLevel == null) {
			QuantumAtomMod.LOGGER.error("Destination dimension for layer {} is not loaded!", targetLayer);
			player.method_7353(
					class_2561.method_43470("Subatomic dimension " + targetLayer.displayName() + " is not loaded!"),
					false
			);
			return false;
		}

		QuantumJourneyState state = getJourneyState(playerId);
		class_243 lookForward = getHorizontalForward(player);
		class_243 destPos = new class_243(
				Math.floor(player.method_23317()) + 0.5,
				SUBATOMIC_ANCHOR_Y,
				Math.floor(player.method_23321()) + 0.5
		);

		class_5321<class_1937> macroSourceDim = state.macroDimension;
		class_2338 anchorBlockPos = state.anchorBlockPos;
		AtomElement targetElement = state.selectedElement;
		boolean targetIsProton = state.selectedIsProton;
		String sourceLabel;

		switch (currentLayer) {
			case OVERWORLD -> {
				anchorBlockPos = findAnchorBlock(sourceLevel, player);
				SyncedBlockContext preview = BlockChemistryMapper.mapNeighborhood(sourceLevel, anchorBlockPos);

				state.macroDimension = sourceLevel.method_27983();
				state.macroReturnPos = player.method_19538();
				state.macroYRot = player.method_36454();
				state.macroXRot = player.method_36455();
				state.anchorBlockPos = anchorBlockPos;
				state.syncedBlockName = preview.blockDisplayName();
				state.syncedChemicalFormula = preview.chemicalFormula();
				state.primaryMacroElement = preview.primaryElement();
				state.selectedElement = preview.primaryElement();

				macroSourceDim = sourceLevel.method_27983();
				targetElement = preview.primaryElement();
				sourceLabel = formatSourceLabel(state.syncedBlockName, state.syncedChemicalFormula);
			}
			case ATOMIC -> {
				AtomEntity targetAtom = findBestTargetAtom(sourceLevel, player);
				targetElement = targetAtom != null
						? targetAtom.getElement()
						: (state.selectedElement != null ? state.selectedElement : AtomElement.CARBON);

				state.atomicReturnPos = player.method_19538();
				state.atomicYRot = player.method_36454();
				state.atomicXRot = player.method_36455();
				state.selectedElement = targetElement;

				if (targetAtom != null && !targetAtom.getSourceLabel().isEmpty()) {
					sourceLabel = targetAtom.getSourceLabel();
				} else if (!state.syncedBlockName.isEmpty()) {
					sourceLabel = formatSourceLabel(state.syncedBlockName, state.syncedChemicalFormula);
				} else {
					sourceLabel = targetElement.isotopeName();
					state.syncedBlockName = targetElement.isotopeName();
					state.syncedChemicalFormula = targetElement.electronConfig();
				}
			}
			case NUCLEAR -> {
				AtomEntity targetAtom = findBestTargetAtom(sourceLevel, player);
				targetElement = targetAtom != null
						? targetAtom.getElement()
						: (state.selectedElement != null ? state.selectedElement : AtomElement.CARBON);
				targetIsProton = targetAtom == null || targetAtom.isNearestNucleonProton(player.method_33571());

				state.nuclearReturnPos = player.method_19538();
				state.nuclearYRot = player.method_36454();
				state.nuclearXRot = player.method_36455();
				state.selectedElement = targetElement;
				state.selectedIsProton = targetIsProton;

				if (targetAtom != null && !targetAtom.getSourceLabel().isEmpty()) {
					sourceLabel = targetAtom.getSourceLabel();
				} else if (!state.syncedBlockName.isEmpty()) {
					sourceLabel = formatSourceLabel(state.syncedBlockName, state.syncedChemicalFormula);
				} else {
					sourceLabel = targetElement.isotopeName();
					state.syncedBlockName = targetElement.isotopeName();
					state.syncedChemicalFormula = targetElement.protons() + "p+ / " + targetElement.neutrons() + "n0";
				}
			}
			default -> {
				return false;
			}
		}

		// Clear any manual scale interpolation target and ensure iportal:scaling is clean 1.0x
		ScaleManager.cancelManualInterpolation(playerId);
		ScaleUtils.setIPortalScaling(player, 1.0);

		double startScale = Math.max(0.06, Math.min(2.0, ScaleManager.getBaseScale(player)));
		ChunkLoader preloader = attachPreloader(player, destLevel, destPos);

		ShrinkTransition transition = new ShrinkTransition(
				true,
				currentLayer,
				targetLayer,
				destLevel.method_27983(),
				destPos,
				player.method_36454(),
				player.method_36455(),
				startScale,
				preloader,
				macroSourceDim,
				anchorBlockPos,
				targetElement,
				targetIsProton,
				sourceLabel,
				lookForward
		);
		ACTIVE_TRANSITIONS.put(playerId, transition);

		// Immediately trigger client FOV warp, radial speed-lines, quantum flash, and layered woosh sound
		ServerPlayNetworking.send(player, new ZoomEffectPayload(
				true,
				targetLayer.ordinal(),
				TRANSITION_DURATION_TICKS,
				SWAP_TICK,
				state.syncedBlockName,
				state.syncedChemicalFormula
		));

		player.method_7353(
				class_2561.method_43470(buildDiveStartMessage(targetLayer, state, targetElement, targetIsProton)),
				true
		);
		return true;
	}

	/**
	 * Starts a cinematic 18-tick grow-up transition ascending one scale layer back toward the Overworld:
	 * {@code QUARK -> NUCLEAR -> ATOMIC -> OVERWORLD}.
	 */
	public static boolean startAscendTransition(class_3222 player) {
		MinecraftServer server = player.method_5682();
		if (server == null) {
			return false;
		}
		UUID playerId = player.method_5667();
		if (ACTIVE_TRANSITIONS.containsKey(playerId)) {
			return false;
		}

		class_3218 sourceLevel = player.method_51469();
		ScaleLayer currentLayer = QuantumRealmDimension.getLayer(sourceLevel);
		ScaleLayer targetLayer = currentLayer.shallower();
		if (currentLayer == ScaleLayer.OVERWORLD || targetLayer == null || targetLayer == currentLayer) {
			ScaleManager.resetToMacroscopic(player);
			player.method_7353(
					class_2561.method_43470("Already in Macroscopic World (10^0 m — 1.0x)"),
					true
			);
			return false;
		}

		QuantumJourneyState state = getJourneyState(playerId);
		class_3218 destLevel;
		class_243 destPos;
		float destYRot = player.method_36454();
		float destXRot = player.method_36455();

		if (targetLayer == ScaleLayer.OVERWORLD) {
			destLevel = state.macroDimension != null ? server.method_3847(state.macroDimension) : null;
			if (destLevel == null || QuantumRealmDimension.isSubatomicDimension(destLevel)) {
				destLevel = server.method_30002();
			}
			if (state.macroReturnPos != null) {
				destPos = state.macroReturnPos;
				destYRot = state.macroYRot;
				destXRot = state.macroXRot;
			} else {
				destPos = computeSafeOverworldReturnPos(destLevel, player.method_19538());
			}
		} else {
			destLevel = QuantumRealmDimension.getLevelForLayer(server, targetLayer);
			if (destLevel == null) {
				QuantumAtomMod.LOGGER.error("Destination dimension for layer {} is not loaded!", targetLayer);
				return false;
			}
			if (targetLayer == ScaleLayer.NUCLEAR && state.nuclearReturnPos != null) {
				destPos = state.nuclearReturnPos;
				destYRot = state.nuclearYRot;
				destXRot = state.nuclearXRot;
			} else if (targetLayer == ScaleLayer.ATOMIC && state.atomicReturnPos != null) {
				destPos = state.atomicReturnPos;
				destYRot = state.atomicYRot;
				destXRot = state.atomicXRot;
			} else {
				destPos = new class_243(
						Math.floor(player.method_23317()) + 0.5,
						SUBATOMIC_ANCHOR_Y,
						Math.floor(player.method_23321()) + 0.5
				);
			}
		}

		ScaleManager.cancelManualInterpolation(playerId);
		ScaleUtils.setIPortalScaling(player, 1.0);

		double startScale = Math.max(0.5, Math.min(2.8, ScaleManager.getBaseScale(player)));
		ChunkLoader preloader = attachPreloader(player, destLevel, destPos);

		String sourceLabel = formatSourceLabel(state.syncedBlockName, state.syncedChemicalFormula);
		ShrinkTransition transition = new ShrinkTransition(
				false,
				currentLayer,
				targetLayer,
				destLevel.method_27983(),
				destPos,
				destYRot,
				destXRot,
				startScale,
				preloader,
				state.macroDimension,
				state.anchorBlockPos,
				state.selectedElement != null ? state.selectedElement : AtomElement.CARBON,
				state.selectedIsProton,
				sourceLabel,
				getHorizontalForward(player)
		);
		ACTIVE_TRANSITIONS.put(playerId, transition);

		ServerPlayNetworking.send(player, new ZoomEffectPayload(
				false,
				targetLayer.ordinal(),
				TRANSITION_DURATION_TICKS,
				SWAP_TICK,
				state.syncedBlockName,
				state.syncedChemicalFormula
		));

		player.method_7353(
				class_2561.method_43470("Ascending to " + targetLayer.displayName() + " (" + targetLayer.scaleNotation() + ")..."),
				true
		);
		return true;
	}

	/**
	 * Advances all active 18-tick shrink/grow dimension transitions each server tick.
	 */
	public static void tickServer(MinecraftServer server) {
		if (ACTIVE_TRANSITIONS.isEmpty()) {
			return;
		}

		Iterator<Map.Entry<UUID, ShrinkTransition>> it = ACTIVE_TRANSITIONS.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<UUID, ShrinkTransition> entry = it.next();
			UUID playerId = entry.getKey();
			ShrinkTransition tr = entry.getValue();
			class_3222 player = server.method_3760().method_14602(playerId);

			if (player == null || player.method_31481()) {
				it.remove();
				continue;
			}

			tr.elapsedTicks++;
			int tick = tr.elapsedTicks;
			player.method_38785();

			// Step 1: Pre-populate destination layer ahead of the seamless swap so ImmPtl streams entities to client
			if (!tr.populated && tick >= POPULATE_TICK) {
				populateDestinationForTransition(server, tr);
				tr.populated = true;
			}

			// Step 2: Drive smooth pre-swap scale curve, apex seamless teleport, and post-swap arrival ease-out
			if (tick < SWAP_TICK) {
				double progress = tick / (double) SWAP_TICK;
				double curved = progress * progress; // accelerate rapidly into the warp apex
				double targetApexScale = tr.shrinkingIn ? 0.05 : 3.0;
				double nextScale = tr.startScale * Math.pow(targetApexScale / tr.startScale, curved);
				ScaleUtils.setBaseScale(player, clampTransitionScale(nextScale));
			} else if (!tr.swapped) {
				if (!tr.populated) {
					populateDestinationForTransition(server, tr);
					tr.populated = true;
				}
				executeSeamlessDimensionSwap(server, player, tr);
				tr.swapped = true;
			} else if (tick < TRANSITION_DURATION_TICKS) {
				double postProgress = (tick - SWAP_TICK) / (double) (TRANSITION_DURATION_TICKS - SWAP_TICK);
				double easeOut = 1.0 - Math.pow(1.0 - postProgress, 3.0);
				double arrivalStartScale = tr.shrinkingIn ? 2.2 : 0.15;
				double nextScale = arrivalStartScale * Math.pow(1.0 / arrivalStartScale, easeOut);
				ScaleUtils.setBaseScale(player, clampTransitionScale(nextScale));
			} else {
				// Finalize transition at crisp 1.0x scale inside the new layer
				ScaleUtils.setIPortalScaling(player, 1.0);
				ScaleUtils.setBaseScale(player, 1.0);
				detachPreloader(player, tr.preloader);

				if (tr.targetLayer == ScaleLayer.OVERWORLD) {
					ScaleManager.restoreMacroscopicFlight(player);
				} else {
					QuantumRealmDimension.tickSubatomicPlayer(player);
				}

				QuantumJourneyState state = JOURNEY_STATES.get(playerId);
				player.method_7353(
						class_2561.method_43470(buildArrivalMessage(tr, state)),
						true
				);
				it.remove();
			}
		}
	}

	public static void onPlayerDisconnect(class_3222 player) {
		if (player == null) {
			return;
		}
		UUID playerId = player.method_5667();
		ShrinkTransition active = ACTIVE_TRANSITIONS.remove(playerId);
		if (active != null) {
			detachPreloader(player, active.preloader);
			ScaleUtils.setIPortalScaling(player, 1.0);
			ScaleUtils.setBaseScale(player, 1.0);
		}
		JOURNEY_STATES.remove(playerId);
	}

	private static void populateDestinationForTransition(MinecraftServer server, ShrinkTransition tr) {
		class_3218 destLevel = server.method_3847(tr.destDimension);
		if (destLevel == null) {
			return;
		}

		preloadServerChunks(destLevel, tr.destPos);

		if (tr.shrinkingIn) {
			switch (tr.targetLayer) {
				case ATOMIC -> {
					class_3218 macroLevel = tr.macroSourceDim != null ? server.method_3847(tr.macroSourceDim) : server.method_30002();
					if (macroLevel == null) {
						macroLevel = server.method_30002();
					}
					class_2338 anchor = tr.anchorBlockPos != null ? tr.anchorBlockPos : class_2338.method_49638(tr.destPos);
					QuantumRealmDimension.populateAtomicRealmFromOverworld(destLevel, macroLevel, anchor, tr.destPos);
				}
				case NUCLEAR -> QuantumRealmDimension.populateNuclearRealm(
						destLevel,
						tr.destPos,
						tr.lookForward,
						tr.targetElement,
						tr.sourceLabel
				);
				case QUARK -> QuantumRealmDimension.populateQuarkRealm(
						destLevel,
						tr.destPos,
						tr.targetIsProton,
						tr.targetElement,
						tr.sourceLabel
				);
				case OVERWORLD -> {
					// No population needed when diving (Overworld is the outermost layer)
				}
			}
		} else {
			// When ascending back into a subatomic layer, ensure atoms/nucleus exist if chunks were empty
			if (tr.targetLayer == ScaleLayer.NUCLEAR && !hasNearbyAtom(destLevel, tr.destPos, 96.0)) {
				QuantumRealmDimension.populateNuclearRealm(
						destLevel,
						tr.destPos,
						tr.lookForward,
						tr.targetElement,
						tr.sourceLabel
				);
			} else if (tr.targetLayer == ScaleLayer.ATOMIC && !hasNearbyAtom(destLevel, tr.destPos, 110.0)) {
				class_3218 macroLevel = tr.macroSourceDim != null ? server.method_3847(tr.macroSourceDim) : server.method_30002();
				if (macroLevel != null && tr.anchorBlockPos != null) {
					QuantumRealmDimension.populateAtomicRealmFromOverworld(destLevel, macroLevel, tr.anchorBlockPos, tr.destPos);
				}
			}
		}
	}

	private static void executeSeamlessDimensionSwap(MinecraftServer server, class_3222 player, ShrinkTransition tr) {
		class_3218 destLevel = server.method_3847(tr.destDimension);
		if (destLevel == null) {
			return;
		}

		// Set arrival punch-in scale & destination gaze BEFORE forceTeleportPlayer so Immersive Portals
		// computes the exact arrival eye offset, bounding box, and yaw/pitch in one seamless frame.
		double arrivalStartScale = tr.shrinkingIn ? 2.2 : 0.15;
		ScaleUtils.setIPortalScaling(player, 1.0);
		ScaleUtils.setBaseScale(player, arrivalStartScale);
		player.method_36456(tr.destYRot);
		player.method_36457(tr.destXRot);
		player.method_5847(tr.destYRot);

		// Zero-loading-screen seamless cross-dimension teleport via Immersive Portals v6.0.6
		ServerTeleportationManager.of(server).forceTeleportPlayer(player, tr.destDimension, tr.destPos);

		player.method_38785();
		player.method_18799(class_243.field_1353);
		player.field_6037 = true;

		if (tr.targetLayer != ScaleLayer.OVERWORLD) {
			// Enable smooth 3D zero-G flight immediately on arrival tick so there is zero gravity drop
			QuantumRealmDimension.tickSubatomicPlayer(player);
		}
	}

	private static ChunkLoader attachPreloader(class_3222 player, class_3218 destLevel, class_243 destPos) {
		int cx = ((int) Math.floor(destPos.field_1352)) >> 4;
		int cz = ((int) Math.floor(destPos.field_1350)) >> 4;
		ChunkLoader loader = new ChunkLoader(destLevel.method_27983(), cx, cz, PRELOAD_CHUNK_RADIUS);
		PortalAPI.addChunkLoaderForPlayer(player, loader);
		return loader;
	}

	private static void detachPreloader(class_3222 player, ChunkLoader preloader) {
		if (preloader != null && player != null) {
			PortalAPI.removeChunkLoaderForPlayer(player, preloader);
		}
	}

	private static void preloadServerChunks(class_3218 level, class_243 center) {
		int cx = ((int) Math.floor(center.field_1352)) >> 4;
		int cz = ((int) Math.floor(center.field_1350)) >> 4;
		for (int dx = -PRELOAD_CHUNK_RADIUS; dx <= PRELOAD_CHUNK_RADIUS; dx++) {
			for (int dz = -PRELOAD_CHUNK_RADIUS; dz <= PRELOAD_CHUNK_RADIUS; dz++) {
				level.method_8497(cx + dx, cz + dz);
			}
		}
	}

	private static boolean hasNearbyAtom(class_3218 level, class_243 center, double radius) {
		class_238 box = class_238.method_30048(center, radius * 2.0, radius * 2.0, radius * 2.0);
		return !level.method_18467(AtomEntity.class, box).isEmpty();
	}

	/**
	 * Finds the Overworld block the player is aiming at (including fluids like Water), or falls back
	 * to the block at/under their feet or nearest non-air block in the immediate 3x3x3 neighborhood.
	 */
	private static class_2338 findAnchorBlock(class_3218 level, class_3222 player) {
		class_243 eyePos = player.method_33571();
		class_243 reachEnd = eyePos.method_1019(player.method_5720().method_1021(10.0));
		class_3965 hit = level.method_17742(new class_3959(
				eyePos,
				reachEnd,
				class_3959.class_3960.field_17559,
				class_3959.class_242.field_1347,
				player
		));
		if (hit.method_17783() == class_239.class_240.field_1332) {
			class_2338 hitPos = hit.method_17777();
			if (!level.method_8320(hitPos).method_26215()) {
				return hitPos;
			}
		}

		class_2338 feetPos = player.method_24515();
		if (!level.method_8320(feetPos).method_26215()) {
			return feetPos;
		}
		class_2338 belowPos = feetPos.method_10074();
		if (!level.method_8320(belowPos).method_26215()) {
			return belowPos;
		}

		// Search immediate 3x3x3 neighborhood for nearest solid/fluid block
		class_2338 closest = null;
		double closestDistSqr = Double.MAX_VALUE;
		for (int dx = -1; dx <= 1; dx++) {
			for (int dy = -1; dy <= 1; dy++) {
				for (int dz = -1; dz <= 1; dz++) {
					class_2338 candidate = feetPos.method_10069(dx, dy, dz);
					class_2680 state = level.method_8320(candidate);
					if (!state.method_26215()) {
						double d2 = candidate.method_19770(eyePos);
						if (d2 < closestDistSqr) {
							closestDistSqr = d2;
							closest = candidate;
						}
					}
				}
			}
		}
		return closest != null ? closest : feetPos;
	}

	/**
	 * Selects the best {@link AtomEntity} target in a subatomic dimension, prioritizing atoms
	 * the player is either very close to / inside OR looking directly toward.
	 */
	private static AtomEntity findBestTargetAtom(class_3218 level, class_3222 player) {
		class_243 eyePos = player.method_33571();
		class_243 look = player.method_5720().method_1029();
		class_238 searchBox = class_238.method_30048(eyePos, 256.0, 256.0, 256.0);
		List<AtomEntity> atoms = level.method_18467(AtomEntity.class, searchBox);
		if (atoms.isEmpty()) {
			return null;
		}

		AtomEntity best = null;
		double bestScore = Double.MAX_VALUE;
		for (AtomEntity atom : atoms) {
			class_243 toAtom = atom.method_19538().method_1020(eyePos);
			double dist = toAtom.method_1033();
			if (dist < 1.0E-4) {
				return atom;
			}
			// Lower score is better: close atoms and aimed-at atoms win strongly
			double dot = look.method_1026(toAtom.method_1021(1.0 / dist));
			double aimMultiplier = dot > 0.6 ? (1.0 - 0.55 * (dot - 0.6) / 0.4) : 1.15;
			double score = dist * aimMultiplier;
			if (score < bestScore) {
				bestScore = score;
				best = atom;
			}
		}
		return best;
	}

	private static class_243 getHorizontalForward(class_3222 player) {
		class_243 look = player.method_5720();
		class_243 horizontal = new class_243(look.field_1352, 0.0, look.field_1350);
		if (horizontal.method_1027() < 1.0E-4) {
			horizontal = class_243.method_1030(0.0f, player.method_36454());
		}
		return horizontal.method_1029();
	}

	private static class_243 computeSafeOverworldReturnPos(class_3218 overworld, class_243 subatomicPos) {
		int bx = (int) Math.floor(subatomicPos.field_1352);
		int bz = (int) Math.floor(subatomicPos.field_1350);
		overworld.method_8497(bx >> 4, bz >> 4);
		int surfaceY = overworld.method_8624(class_2902.class_2903.field_13203, bx, bz);
		if (surfaceY <= overworld.method_31607() + 2) {
			class_2338 spawn = overworld.method_43126();
			return new class_243(spawn.method_10263() + 0.5, spawn.method_10264() + 1.0, spawn.method_10260() + 0.5);
		}
		return new class_243(bx + 0.5, surfaceY + 1.0, bz + 0.5);
	}

	private static double clampTransitionScale(double value) {
		return Math.max(ScaleManager.MIN_SCALE, Math.min(ScaleManager.MAX_SCALE, value));
	}

	private static String formatSourceLabel(String blockName, String formula) {
		if (blockName == null || blockName.isEmpty()) {
			return formula != null ? formula : "";
		}
		if (formula == null || formula.isEmpty()) {
			return blockName;
		}
		return blockName + " — " + formula;
	}

	private static String buildDiveStartMessage(
			ScaleLayer targetLayer,
			QuantumJourneyState state,
			AtomElement element,
			boolean isProton
	) {
		return switch (targetLayer) {
			case ATOMIC -> "Shrinking into " + state.syncedBlockName + " [" + state.syncedChemicalFormula + "] — 10^-10 m...";
			case NUCLEAR -> "Diving into " + element.isotopeName() + " Nucleus (" + element.protons() + "p+ / " + element.neutrons() + "n0) — 10^-15 m...";
			case QUARK -> "Entering " + (isProton ? "PROTON (uud)" : "NEUTRON (udd)") + " of " + element.isotopeName() + " — 10^-18 m...";
			case OVERWORLD -> "Transitioning to Overworld...";
		};
	}

	private static String buildArrivalMessage(ShrinkTransition tr, QuantumJourneyState state) {
		return switch (tr.targetLayer) {
			case OVERWORLD -> "Macroscopic World (10^0 m — 1.0x)";
			case ATOMIC -> {
				String chem = state != null && !state.syncedBlockName.isEmpty()
						? " | " + state.syncedBlockName + " (" + state.syncedChemicalFormula + ")"
						: "";
				yield "Atomic Realm (10^-10 m)" + chem;
			}
			case NUCLEAR -> "Nuclear Realm (10^-15 m) | " + tr.targetElement.isotopeName()
					+ " (" + tr.targetElement.protons() + "p+ / " + tr.targetElement.neutrons() + "n0)";
			case QUARK -> "Quark Realm (10^-18 m) | Inside "
					+ (tr.targetIsProton ? "PROTON (uud, +1e)" : "NEUTRON (udd, 0e)")
					+ " — QCD Confinement Cavity";
		};
	}
}

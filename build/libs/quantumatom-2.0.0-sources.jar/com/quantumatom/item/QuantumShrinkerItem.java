package com.quantumatom.item;

import com.quantumatom.portal.QuantumPortalManager;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;

/**
 * Handheld Ant-Man style Quantum Shrinker driving seamless multi-dimension zoom transitions
 * across the 4 subatomic scale tiers:
 * {@code Overworld (10^0 m) <-> Atomic Realm (10^-10 m) <-> Nuclear Realm (10^-15 m) <-> Quark Realm (10^-18 m)}.
 * <ul>
 *   <li><b>Right-Click:</b> Shrink deeper one scale layer with cinematic FOV warp, radial speed-lines,
 *       layered woosh audio, and zero-loading-screen Immersive Portals dimension swap.</li>
 *   <li><b>Shift + Right-Click:</b> Grow back up one scale layer toward the macroscopic Overworld.</li>
 * </ul>
 */
public class QuantumShrinkerItem extends class_1792 {
	public QuantumShrinkerItem(class_1793 properties) {
		super(properties);
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
		class_1799 stack = player.method_5998(hand);
		if (!level.field_9236 && player instanceof class_3222 serverPlayer) {
			boolean started = serverPlayer.method_5715()
					? QuantumPortalManager.startAscendTransition(serverPlayer)
					: QuantumPortalManager.startDiveTransition(serverPlayer);

			if (started) {
				// Cooldown covers the 18-tick cinematic zoom transition to prevent accidental double-triggers
				serverPlayer.method_7357().method_7906(this, QuantumPortalManager.TRANSITION_DURATION_TICKS + 2);
			} else {
				serverPlayer.method_7357().method_7906(this, 8);
			}
		}
		return class_1271.method_29237(stack, level.field_9236);
	}
}

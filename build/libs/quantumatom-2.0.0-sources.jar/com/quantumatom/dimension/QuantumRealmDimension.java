package com.quantumatom.dimension;

import com.quantumatom.QuantumAtomMod;
import com.quantumatom.entity.AtomEntity;
import com.quantumatom.science.AtomElement;
import com.quantumatom.science.BlockChemistryMapper;
import com.quantumatom.science.BlockChemistryMapper.PlacedAtomSpec;
import com.quantumatom.science.BlockChemistryMapper.SyncedBlockContext;
import com.quantumatom.science.OrbitalSampler;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1324;
import net.minecraft.class_1656;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2874;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Multi-dimension 4-tier subatomic scale hierarchy and realm population manager:
 * <ol>
 *   <li>{@link ScaleLayer#OVERWORLD} ({@code 10^0 m}) — Macroscopic Minecraft world</li>
 *   <li>{@link ScaleLayer#ATOMIC} ({@code quantumatom:atomic_realm}, {@code 10^-10 m}) — Electron clouds synchronized to Overworld blocks</li>
 *   <li>{@link ScaleLayer#NUCLEAR} ({@code quantumatom:nuclear_realm}, {@code 10^-15 m}) — Colossal atomic nucleus (Protons &amp; Neutrons)</li>
 *   <li>{@link ScaleLayer#QUARK} ({@code quantumatom:quark_realm}, {@code 10^-18 m}) — Interior of a Proton ({@code uud}) or Neutron ({@code udd})</li>
 * </ol>
 */
public final class QuantumRealmDimension {
	public enum ScaleLayer {
		OVERWORLD("Overworld", "10^0 m", "Macroscopic World"),
		ATOMIC("Atomic Realm", "10^-10 m", "Picometer — Electron Wave Clouds"),
		NUCLEAR("Nuclear Realm", "10^-15 m", "Femtometer — Protons & Neutrons"),
		QUARK("Quark Realm", "10^-18 m", "Attometer — Valence Quarks & Gluons");

		private final String displayName;
		private final String scaleNotation;
		private final String scaleDescription;

		ScaleLayer(String displayName, String scaleNotation, String scaleDescription) {
			this.displayName = displayName;
			this.scaleNotation = scaleNotation;
			this.scaleDescription = scaleDescription;
		}

		public String displayName() {
			return displayName;
		}

		public String scaleNotation() {
			return scaleNotation;
		}

		public String scaleDescription() {
			return scaleDescription;
		}

		public ScaleLayer deeper() {
			return switch (this) {
				case OVERWORLD -> ATOMIC;
				case ATOMIC -> NUCLEAR;
				case NUCLEAR -> QUARK;
				case QUARK -> null;
			};
		}

		public ScaleLayer shallower() {
			return switch (this) {
				case OVERWORLD -> null;
				case ATOMIC -> OVERWORLD;
				case NUCLEAR -> ATOMIC;
				case QUARK -> NUCLEAR;
			};
		}

		public static ScaleLayer fromOrdinal(int ordinal) {
			ScaleLayer[] values = values();
			if (ordinal < 0 || ordinal >= values.length) {
				return OVERWORLD;
			}
			return values[ordinal];
		}
	}

	public static final class_5321<class_1937> ATOMIC_REALM_KEY =
			class_5321.method_29179(class_7924.field_41223, QuantumAtomMod.id("atomic_realm"));
	public static final class_5321<class_1937> NUCLEAR_REALM_KEY =
			class_5321.method_29179(class_7924.field_41223, QuantumAtomMod.id("nuclear_realm"));
	public static final class_5321<class_1937> QUARK_REALM_KEY =
			class_5321.method_29179(class_7924.field_41223, QuantumAtomMod.id("quark_realm"));

	public static final class_5321<class_2874> ATOMIC_REALM_TYPE_KEY =
			class_5321.method_29179(class_7924.field_41241, QuantumAtomMod.id("atomic_realm"));
	public static final class_5321<class_2874> NUCLEAR_REALM_TYPE_KEY =
			class_5321.method_29179(class_7924.field_41241, QuantumAtomMod.id("nuclear_realm"));
	public static final class_5321<class_2874> QUARK_REALM_TYPE_KEY =
			class_5321.method_29179(class_7924.field_41241, QuantumAtomMod.id("quark_realm"));

	private static final double STALE_CLEAR_RADIUS = 140.0;
	private static final double ATOM_VERTICAL_MARGIN = 18.0;
	private static final double PLAYER_VERTICAL_MARGIN = 8.0;
	private static final double NUCLEAR_BASE_NUCLEON_RADIUS = 2.4;

	private static final float DEFAULT_FLYING_SPEED = 0.05f;
	private static final float ATOMIC_FLYING_SPEED = 0.058f;

	private static final Set<UUID> PLAYERS_IN_SUBATOMIC = ConcurrentHashMap.newKeySet();

	private QuantumRealmDimension() {
	}

	/**
	 * Returns the {@link ScaleLayer} corresponding to the given level.
	 */
	public static ScaleLayer getLayer(class_1937 level) {
		return level != null ? getLayer(level.method_27983()) : ScaleLayer.OVERWORLD;
	}

	/**
	 * Returns the {@link ScaleLayer} corresponding to the given dimension key.
	 */
	public static ScaleLayer getLayer(class_5321<class_1937> dimensionKey) {
		if (dimensionKey == null) {
			return ScaleLayer.OVERWORLD;
		}
		if (dimensionKey.equals(ATOMIC_REALM_KEY)) {
			return ScaleLayer.ATOMIC;
		}
		if (dimensionKey.equals(NUCLEAR_REALM_KEY)) {
			return ScaleLayer.NUCLEAR;
		}
		if (dimensionKey.equals(QUARK_REALM_KEY)) {
			return ScaleLayer.QUARK;
		}
		return ScaleLayer.OVERWORLD;
	}

	/**
	 * Returns {@code true} if {@code level} is any of the 3 dedicated subatomic dimensions
	 * ({@code atomic_realm}, {@code nuclear_realm}, or {@code quark_realm}).
	 */
	public static boolean isSubatomicDimension(class_1937 level) {
		return getLayer(level) != ScaleLayer.OVERWORLD;
	}

	/**
	 * Resolves the {@link class_3218} for the requested {@link ScaleLayer}, or {@code null} if unavailable.
	 */
	public static class_3218 getLevelForLayer(MinecraftServer server, ScaleLayer layer) {
		if (server == null || layer == null) {
			return null;
		}
		return switch (layer) {
			case OVERWORLD -> server.method_30002();
			case ATOMIC -> server.method_3847(ATOMIC_REALM_KEY);
			case NUCLEAR -> server.method_3847(NUCLEAR_REALM_KEY);
			case QUARK -> server.method_3847(QUARK_REALM_KEY);
		};
	}

	/**
	 * Clears stale atoms around {@code destCenter} in {@code atomicLevel} and spawns a spatially
	 * synchronized 3D constellation of floating {@link AtomEntity} instances in
	 * {@link AtomEntity.RenderMode#ATOMIC_CLOUD} mirroring the exact Minecraft blocks in the
	 * {@code 3x3x3} Overworld neighborhood around {@code anchorBlockPos}.
	 */
	public static SyncedBlockContext populateAtomicRealmFromOverworld(
			class_3218 atomicLevel,
			class_3218 overworld,
			class_2338 anchorBlockPos,
			class_243 destCenter
	) {
		if (atomicLevel == null || overworld == null || anchorBlockPos == null || destCenter == null) {
			return new SyncedBlockContext("Air", "Earth Atmosphere (78% N2, 21% O2)", AtomElement.NITROGEN, List.of());
		}

		clearNearbyAtoms(atomicLevel, destCenter, STALE_CLEAR_RADIUS);
		SyncedBlockContext context = BlockChemistryMapper.mapNeighborhood(overworld, anchorBlockPos);

		for (PlacedAtomSpec spec : context.atoms()) {
			class_243 offset = spec.relativeOffset();
			double x = destCenter.field_1352 + offset.field_1352;
			double y = clampAtomY(atomicLevel, destCenter.field_1351 + offset.field_1351);
			double z = destCenter.field_1350 + offset.field_1350;

			AtomEntity atom = new AtomEntity(QuantumAtomMod.ATOM_ENTITY, atomicLevel);
			atom.method_5814(x, y, z);
			atom.setElement(spec.element());
			atom.setAtomScale(spec.scale());
			atom.setRenderMode(AtomEntity.RenderMode.ATOMIC_CLOUD);
			atom.setProtonInterior(false);
			atom.setSourceLabel(spec.label());
			atomicLevel.method_8649(atom);
		}

		return context;
	}

	/**
	 * Clears stale entities near {@code destCenter} in {@code nuclearLevel} and spawns a colossal
	 * {@link AtomEntity} in {@link AtomEntity.RenderMode#NUCLEUS_ONLY} directly in front of
	 * {@code destCenter} (along {@code -Z}).
	 */
	public static AtomEntity populateNuclearRealm(
			class_3218 nuclearLevel,
			class_243 destCenter,
			AtomElement element,
			String sourceLabel
	) {
		return populateNuclearRealm(nuclearLevel, destCenter, new class_243(0.0, 0.0, -1.0), element, sourceLabel);
	}

	/**
	 * Clears stale entities near {@code destCenter} in {@code nuclearLevel} and spawns a colossal
	 * {@link AtomEntity} in {@link AtomEntity.RenderMode#NUCLEUS_ONLY} framed cleanly ahead of
	 * the player along {@code forwardDir}.
	 */
	public static AtomEntity populateNuclearRealm(
			class_3218 nuclearLevel,
			class_243 destCenter,
			class_243 forwardDir,
			AtomElement element,
			String sourceLabel
	) {
		if (nuclearLevel == null || destCenter == null) {
			return null;
		}

		AtomElement targetElement = element != null ? element : AtomElement.CARBON;
		clearNearbyAtoms(nuclearLevel, destCenter, STALE_CLEAR_RADIUS);

		float atomScale = computeNuclearScale(targetElement);
		double nucleonRadius = NUCLEAR_BASE_NUCLEON_RADIUS * atomScale;
		double clusterRadius = OrbitalSampler.getNucleusClusterRadius(targetElement, nucleonRadius);
		double forwardDist = Math.max(20.0, Math.min(46.0, clusterRadius + 16.0));

		class_243 dir = (forwardDir != null && forwardDir.method_1027() > 1.0e-4)
				? forwardDir.method_1029()
				: new class_243(0.0, 0.0, -1.0);

		double spawnX = destCenter.field_1352 + dir.field_1352 * forwardDist;
		double spawnY = clampAtomY(nuclearLevel, destCenter.field_1351 + dir.field_1351 * forwardDist + 1.5);
		double spawnZ = destCenter.field_1350 + dir.field_1350 * forwardDist;

		String resolvedLabel = (sourceLabel != null && !sourceLabel.isBlank())
				? sourceLabel
				: targetElement.isotopeName() + " Nucleus";

		AtomEntity nucleus = new AtomEntity(QuantumAtomMod.ATOM_ENTITY, nuclearLevel);
		nucleus.method_5814(spawnX, spawnY, spawnZ);
		nucleus.setElement(targetElement);
		nucleus.setAtomScale(atomScale);
		nucleus.setRenderMode(AtomEntity.RenderMode.NUCLEUS_ONLY);
		nucleus.setProtonInterior(true);
		nucleus.setSourceLabel(resolvedLabel);
		nuclearLevel.method_8649(nucleus);
		return nucleus;
	}

	/**
	 * Clears stale entities near {@code destCenter} in {@code quarkLevel} and spawns a colossal
	 * {@link AtomEntity} in {@link AtomEntity.RenderMode#QUARK_INTERIOR} centered directly at
	 * {@code destCenter} so the player arrives inside the glowing Proton ({@code uud}) or
	 * Neutron ({@code udd}) QCD confinement cavity.
	 */
	public static AtomEntity populateQuarkRealm(
			class_3218 quarkLevel,
			class_243 destCenter,
			boolean isProton,
			AtomElement parentElement,
			String sourceLabel
	) {
		if (quarkLevel == null || destCenter == null) {
			return null;
		}

		AtomElement element = parentElement != null ? parentElement : AtomElement.CARBON;
		clearNearbyAtoms(quarkLevel, destCenter, STALE_CLEAR_RADIUS);

		double spawnY = clampAtomY(quarkLevel, destCenter.field_1351);
		String resolvedLabel = (sourceLabel != null && !sourceLabel.isBlank())
				? sourceLabel
				: (isProton ? "PROTON (uud)" : "NEUTRON (udd)") + " — " + element.isotopeName();

		AtomEntity cavity = new AtomEntity(QuantumAtomMod.ATOM_ENTITY, quarkLevel);
		cavity.method_5814(destCenter.field_1352, spawnY, destCenter.field_1350);
		cavity.setElement(element);
		cavity.setAtomScale(2.0f);
		cavity.setRenderMode(AtomEntity.RenderMode.QUARK_INTERIOR);
		cavity.setProtonInterior(isProton);
		cavity.setSourceLabel(resolvedLabel);
		quarkLevel.method_8649(cavity);
		return cavity;
	}

	/**
	 * Convenience server-tick entry point ticking all online players through
	 * {@link #tickSubatomicPlayer(class_3222)}.
	 */
	public static void tickServer(MinecraftServer server) {
		if (server == null) {
			return;
		}
		for (class_3222 player : server.method_3760().method_14571()) {
			tickSubatomicPlayer(player);
		}
	}

	/**
	 * Grants smooth 3D zero-gravity flight ({@code mayfly}, {@code flying}, invisible slow fall,
	 * and zero fall damage) plus vertical void-bounds buoyancy while {@code player} is inside any
	 * subatomic dimension ({@code atomic_realm}, {@code nuclear_realm}, {@code quark_realm}).
	 * Cleanly restores flight state upon returning to the Overworld.
	 */
	public static void tickSubatomicPlayer(class_3222 player) {
		if (player == null || player.method_31481()) {
			return;
		}

		UUID playerId = player.method_5667();
		ScaleLayer layer = getLayer(player.method_37908());
		if (layer == ScaleLayer.OVERWORLD) {
			handleSubatomicExit(player, playerId);
			return;
		}

		boolean justEntered = PLAYERS_IN_SUBATOMIC.add(playerId);
		class_1656 abilities = player.method_31549();
		boolean abilitiesDirty = false;

		if (!player.method_7325()) {
			if (!abilities.field_7478) {
				abilities.field_7478 = true;
				abilitiesDirty = true;
			}
			if (!abilities.field_7479) {
				abilities.field_7479 = true;
				abilitiesDirty = true;
			}

			float targetFlySpeed = (layer == ScaleLayer.ATOMIC) ? ATOMIC_FLYING_SPEED : DEFAULT_FLYING_SPEED;
			if (Math.abs(abilities.method_7252() - targetFlySpeed) > 0.002f) {
				abilities.method_7248(targetFlySpeed);
				abilitiesDirty = true;
			}
		}

		if (abilitiesDirty || justEntered) {
			player.method_7355();
		}

		// Zero fall damage & subtle invisible slow-fall cushion
		player.method_38785();
		class_1293 slowFall = player.method_6112(class_1294.field_5906);
		if (slowFall == null || slowFall.method_5584() < 40) {
			player.method_6092(new class_1293(class_1294.field_5906, 80, 0, true, false, false));
		}

		// Soft vertical buoyancy so players cannot drift into void damage below min_y or above max_y
		class_3218 subatomicLevel = player.method_51469();
		double lowerBound = subatomicLevel.method_31607() + PLAYER_VERTICAL_MARGIN;
		double upperBound = subatomicLevel.method_31600() - PLAYER_VERTICAL_MARGIN;
		if (player.method_23318() < lowerBound) {
			class_243 velocity = player.method_18798();
			player.method_18800(velocity.field_1352, Math.max(velocity.field_1351, 0.35), velocity.field_1350);
			player.field_6037 = true;
		} else if (player.method_23318() > upperBound) {
			class_243 velocity = player.method_18798();
			player.method_18800(velocity.field_1352, Math.min(velocity.field_1351, -0.25), velocity.field_1350);
			player.field_6037 = true;
		}
	}

	/**
	 * Cleans up per-player tracking when a player disconnects.
	 */
	public static void onPlayerDisconnect(class_3222 player) {
		if (player != null) {
			PLAYERS_IN_SUBATOMIC.remove(player.method_5667());
		}
	}

	private static void handleSubatomicExit(class_3222 player, UUID playerId) {
		if (!PLAYERS_IN_SUBATOMIC.remove(playerId)) {
			return;
		}
		player.method_38785();

		class_1656 abilities = player.method_31549();
		boolean dirty = false;
		if (Math.abs(abilities.method_7252() - DEFAULT_FLYING_SPEED) > 0.001f) {
			abilities.method_7248(DEFAULT_FLYING_SPEED);
			dirty = true;
		}

		if (!player.method_7337() && !player.method_7325() && getEffectiveScale(player) >= 0.95) {
			if (abilities.field_7478 || abilities.field_7479) {
				abilities.field_7478 = false;
				abilities.field_7479 = false;
				dirty = true;
			}
		}

		if (dirty) {
			player.method_7355();
		}
	}

	private static void clearNearbyAtoms(class_3218 level, class_243 center, double radius) {
		class_238 box = class_238.method_30048(center, radius * 2.0, radius * 2.0, radius * 2.0);
		List<AtomEntity> stale = level.method_18467(AtomEntity.class, box);
		for (AtomEntity atom : stale) {
			atom.method_31472();
		}
	}

	private static float computeNuclearScale(AtomElement element) {
		int nucleons = element.totalNucleons();
		if (nucleons >= 140) {
			return 1.10f;
		}
		if (nucleons >= 48) {
			return 1.35f;
		}
		return 1.65f;
	}

	private static double clampAtomY(class_3218 level, double y) {
		double minY = level.method_31607() + ATOM_VERTICAL_MARGIN;
		double maxY = level.method_31600() - ATOM_VERTICAL_MARGIN;
		return Math.max(minY, Math.min(maxY, y));
	}

	private static double getEffectiveScale(class_3222 player) {
		class_1324 attr = player.method_5996(class_5134.field_47760);
		return attr != null ? attr.method_6194() : 1.0;
	}
}

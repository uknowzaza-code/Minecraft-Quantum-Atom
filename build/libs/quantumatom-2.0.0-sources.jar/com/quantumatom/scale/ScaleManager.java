package com.quantumatom.scale;

import com.quantumatom.dimension.QuantumRealmDimension;
import com.quantumatom.dimension.QuantumRealmDimension.ScaleLayer;
import com.quantumatom.portal.QuantumPortalManager;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.server.MinecraftServer;
import qouteall.imm_ptl.core.ScaleUtils;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages smooth logarithmic player scale interpolation and automatically triggers seamless
 * multi-dimension transitions via {@link QuantumPortalManager} whenever manual scaling crosses
 * the shrink-dive threshold ({@code < 0.12}) or grow-ascend threshold ({@code > 2.5}).
 */
public final class ScaleManager {
	public static final double MIN_SCALE = 0.005;
	public static final double MAX_SCALE = 16.0;

	/** Crossing below this scale via {@code /atom scale} automatically dives one subatomic layer deeper. */
	public static final double SHRINK_DIVE_THRESHOLD = 0.12;

	/** Crossing above this scale via {@code /atom scale} automatically ascends one layer shallower. */
	public static final double GROW_ASCEND_THRESHOLD = 2.5;

	private static final Map<UUID, Double> TARGET_BASE_SCALES = new ConcurrentHashMap<>();

	private ScaleManager() {
	}

	/**
	 * Returns the player's effective scale ({@code Attributes.SCALE} total value).
	 */
	public static double getScale(class_1657 player) {
		class_1324 attr = player.method_5996(class_5134.field_47760);
		return attr != null ? attr.method_6194() : 1.0;
	}

	/**
	 * Returns the player's base {@code Attributes.SCALE} value.
	 */
	public static double getBaseScale(class_1657 player) {
		class_1324 attr = player.method_5996(class_5134.field_47760);
		return attr != null ? attr.method_6201() : 1.0;
	}

	/**
	 * Returns the active Immersive Portals {@code iportal:scaling} multiplier on {@code player}.
	 */
	public static double getIPortalScale(class_1657 player) {
		return ScaleUtils.getIPortalScaling(player);
	}

	/**
	 * Smoothly interpolates the player's scale toward {@code targetBaseScale}.
	 * If a player shrinks below {@link #SHRINK_DIVE_THRESHOLD} or expands above
	 * {@link #GROW_ASCEND_THRESHOLD}, {@link #tickServer(MinecraftServer)} automatically
	 * triggers a seamless cross-dimension zoom transition.
	 */
	public static void setScale(class_1657 player, double targetBaseScale) {
		if (QuantumPortalManager.isTransitioning(player.method_5667())) {
			return;
		}
		double clamped = clampScale(targetBaseScale);
		TARGET_BASE_SCALES.put(player.method_5667(), clamped);
		applyMacroFlightState(player, clamped);
	}

	/**
	 * Immediately sets the player's base scale to {@code targetBaseScale}.
	 */
	public static void setScaleImmediate(class_1657 player, double targetBaseScale) {
		double clamped = clampScale(targetBaseScale);
		TARGET_BASE_SCALES.remove(player.method_5667());
		ScaleUtils.setBaseScale(player, clamped);
		applyMacroFlightState(player, clamped);
	}

	/**
	 * Smoothly resets the player to macroscopic {@code 1.0x} scale, clearing any residual
	 * Immersive Portals scaling modifier.
	 */
	public static void resetToMacroscopic(class_1657 player) {
		ScaleUtils.setIPortalScaling(player, 1.0);
		setScale(player, 1.0);
	}

	/**
	 * Cancels any pending manual scale interpolation (invoked when a cinematic dimension transition takes over).
	 */
	public static void cancelManualInterpolation(UUID playerId) {
		if (playerId != null) {
			TARGET_BASE_SCALES.remove(playerId);
		}
	}

	/**
	 * Restores normal Overworld survival flight rules after ascending back to the macroscopic world.
	 */
	public static void restoreMacroscopicFlight(class_3222 player) {
		player.method_38785();
		if (!player.method_7337() && !player.method_7325()) {
			if (player.method_31549().field_7478 || player.method_31549().field_7479) {
				player.method_31549().field_7478 = false;
				player.method_31549().field_7479 = false;
				player.method_7355();
			}
		}
	}

	/**
	 * Smoothly interpolates manual player scale targets logarithmically each server tick, and
	 * triggers automatic seamless dimension dives/ascents when crossing scale thresholds.
	 */
	public static void tickServer(MinecraftServer server) {
		if (TARGET_BASE_SCALES.isEmpty()) {
			return;
		}
		for (class_3222 player : server.method_3760().method_14571()) {
			UUID playerId = player.method_5667();
			if (QuantumPortalManager.isTransitioning(playerId)) {
				TARGET_BASE_SCALES.remove(playerId);
				continue;
			}

			Double targetBase = TARGET_BASE_SCALES.get(playerId);
			if (targetBase == null) {
				continue;
			}

			class_1324 attr = player.method_5996(class_5134.field_47760);
			if (attr == null) {
				TARGET_BASE_SCALES.remove(playerId);
				continue;
			}

			double currentBase = attr.method_6201();
			double ratio = targetBase / Math.max(MIN_SCALE, currentBase);
			double nextBase;
			if (Math.abs(ratio - 1.0) < 0.015) {
				nextBase = targetBase;
				TARGET_BASE_SCALES.remove(playerId);
				ScaleUtils.setBaseScale(player, nextBase);
				applyMacroFlightState(player, nextBase);
			} else {
				nextBase = clampScale(currentBase * Math.pow(ratio, 0.26));
				ScaleUtils.setBaseScale(player, nextBase);
			}

			// Automatic threshold-driven seamless dimension transition!
			ScaleLayer layer = QuantumRealmDimension.getLayer(player.method_37908());
			if (nextBase < SHRINK_DIVE_THRESHOLD && layer != ScaleLayer.QUARK) {
				TARGET_BASE_SCALES.remove(playerId);
				QuantumPortalManager.startDiveTransition(player);
			} else if (nextBase > GROW_ASCEND_THRESHOLD && layer != ScaleLayer.OVERWORLD) {
				TARGET_BASE_SCALES.remove(playerId);
				QuantumPortalManager.startAscendTransition(player);
			}
		}
	}

	public static void onPlayerDisconnect(class_3222 player) {
		if (player != null) {
			TARGET_BASE_SCALES.remove(player.method_5667());
		}
	}

	public static String describeScale(double scale) {
		if (scale < SHRINK_DIVE_THRESHOLD) {
			return "Quantum Dive Threshold (< 0.12x)";
		} else if (scale < 0.95) {
			return "Shrinking (" + String.format("%.2fx", scale) + ")";
		} else if (scale > GROW_ASCEND_THRESHOLD) {
			return "Ascend Threshold (> 2.5x)";
		} else if (scale > 1.05) {
			return "Expanding (" + String.format("%.2fx", scale) + ")";
		}
		return "Standard Scale (1.0x)";
	}

	private static void applyMacroFlightState(class_1657 player, double targetBaseScale) {
		if (QuantumRealmDimension.isSubatomicDimension(player.method_37908())) {
			return;
		}
		if (!player.method_7337() && !player.method_7325()) {
			boolean shrunk = targetBaseScale < 0.95;
			if (player.method_31549().field_7478 != shrunk || (!shrunk && player.method_31549().field_7479)) {
				player.method_31549().field_7478 = shrunk;
				player.method_31549().field_7479 = shrunk;
				player.method_7355();
			}
		}
	}

	private static double clampScale(double value) {
		return Math.max(MIN_SCALE, Math.min(MAX_SCALE, value));
	}
}

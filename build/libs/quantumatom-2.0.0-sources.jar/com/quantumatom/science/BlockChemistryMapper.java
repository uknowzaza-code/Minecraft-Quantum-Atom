package com.quantumatom.science;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_7923;

/**
 * Maps real Minecraft Overworld blocks and their surrounding {@code 3x3x3} spatial neighborhood
 * to Wikipedia-verified chemical formulas and spatially synchronized 3D atomic/molecular clusters
 * for the {@code quantumatom:atomic_realm} dimension.
 */
public final class BlockChemistryMapper {
	/** Spacing in Atomic Realm blocks corresponding to a 1-block step in the Overworld 3x3x3 grid. */
	private static final double NEIGHBOR_BLOCK_SPACING = 46.0;
	private static final double NEIGHBOR_VERTICAL_SPACING = 42.0;

	/** Maximum total atoms spawned for a synchronized 3x3x3 neighborhood (keeps FPS smooth). */
	private static final int MAX_SYNCED_ATOMS = 18;

	/** Minimum clearance from the player spawn center (0,0,0) and between non-bonded clusters. */
	private static final double MIN_SPAWN_CLEARANCE_SQR = 14.0 * 14.0;
	private static final double MIN_CLUSTER_SEPARATION_SQR = 26.0 * 26.0;

	/** Exact water H-O-H bond angle (104.5 degrees -> half angle 52.25 degrees). */
	private static final double H2O_HALF_ANGLE_RAD = Math.toRadians(52.25);

	public record PlacedAtomSpec(class_243 relativeOffset, AtomElement element, float scale, String label) {
	}

	public record SyncedBlockContext(
			String blockDisplayName,
			String chemicalFormula,
			AtomElement primaryElement,
			List<PlacedAtomSpec> atoms
	) {
	}

	private enum ChemistryKind {
		WATER("H2O (Water)", AtomElement.OXYGEN),
		ORGANIC_CHON("Organic CHON (Cellulose / Biomolecules)", AtomElement.CARBON),
		PURE_CARBON("Pure Carbon (C-12 Lattice)", AtomElement.CARBON),
		SILICATE("SiO2 (Silicate / Silicon Dioxide)", AtomElement.SILICON),
		IRON_METAL("Fe (Metallic Iron Lattice)", AtomElement.IRON),
		COPPER_METAL("Cu (Metallic Copper Lattice)", AtomElement.COPPER),
		GOLD_METAL("Au (Metallic Gold Lattice)", AtomElement.GOLD),
		CALCIUM_MINERAL("CaCO3 / Ca3(PO4)2 (Calcium Mineral)", AtomElement.CALCIUM),
		MARINE_HALITE("NaCl + SiO2 (Marine Halite / Silicate)", AtomElement.SODIUM),
		LUMINESCENT_MINERAL("SiO2 + P/S (Luminescent Mineral)", AtomElement.PHOSPHORUS),
		VOLCANIC_SILICATE("SiO2 + Fe/S (Volcanic Silicate)", AtomElement.SILICON),
		ATMOSPHERE("Earth Atmosphere (78% N2, 21% O2)", AtomElement.NITROGEN),
		DEFAULT_MINERAL("SiO2 + Fe/Ca (Mineral Composite)", AtomElement.SILICON);

		final String formula;
		final AtomElement primaryElement;

		ChemistryKind(String formula, AtomElement primaryElement) {
			this.formula = formula;
			this.primaryElement = primaryElement;
		}
	}

	private record NeighborOffset(int dx, int dy, int dz) {
		int manhattan() {
			return Math.abs(dx) + Math.abs(dy) + Math.abs(dz);
		}
	}

	/** All 26 surrounding 3x3x3 offsets ordered face-adjacent first, then edge, then corner. */
	private static final List<NeighborOffset> NEIGHBOR_OFFSETS = buildOrderedNeighborOffsets();

	private BlockChemistryMapper() {
	}

	/**
	 * Inspects {@code anchorBlockPos} and its surrounding {@code 3x3x3} block neighborhood in
	 * {@code overworld}, producing a spatially synchronized list of floating 3D atoms whose
	 * chemistry and relative positions mirror the real blocks around the player.
	 */
	public static SyncedBlockContext mapNeighborhood(class_3218 overworld, class_2338 anchorBlockPos) {
		class_2680 anchorState = overworld.method_8320(anchorBlockPos);
		ChemistryKind anchorKind = classifyBlock(overworld, anchorBlockPos, anchorState);
		String blockName = resolveDisplayName(anchorState);
		String anchorLabel = formatAtomLabel(blockName, anchorKind.formula);

		List<PlacedAtomSpec> placed = new ArrayList<>(MAX_SYNCED_ATOMS);
		List<class_243> clusterCenters = new ArrayList<>();

		// 1. Place the anchor block's signature molecular/lattice cluster prominently near the arrival point
		class_243 primaryCenter = new class_243(0.0, 2.5, -22.0);
		addPrimaryCluster(placed, anchorKind, primaryCenter, anchorLabel);
		clusterCenters.add(primaryCenter);

		// 2. Scan the 3x3x3 neighborhood: prioritize real solid/fluid neighbors first, then atmospheric air
		List<NeighborOffset> nonAirNeighbors = new ArrayList<>();
		List<NeighborOffset> airNeighbors = new ArrayList<>();
		for (NeighborOffset off : NEIGHBOR_OFFSETS) {
			class_2338 pos = anchorBlockPos.method_10069(off.dx(), off.dy(), off.dz());
			class_2680 state = overworld.method_8320(pos);
			if (state.method_26215() && state.method_26227().method_15769()) {
				airNeighbors.add(off);
			} else {
				nonAirNeighbors.add(off);
			}
		}

		// Place spatially mirrored atoms for real surrounding blocks
		for (NeighborOffset off : nonAirNeighbors) {
			if (placed.size() >= MAX_SYNCED_ATOMS) {
				break;
			}
			class_2338 pos = anchorBlockPos.method_10069(off.dx(), off.dy(), off.dz());
			class_2680 state = overworld.method_8320(pos);
			ChemistryKind kind = classifyBlock(overworld, pos, state);
			String label = formatAtomLabel(resolveDisplayName(state), kind.formula);
			placeNeighborCluster(placed, clusterCenters, off, pos, kind, label);
		}

		// Fill remaining spatial directions (e.g. open sky above ground blocks) with atmospheric N2/O2 pairs
		int airAdded = 0;
		for (NeighborOffset off : airNeighbors) {
			if (placed.size() >= MAX_SYNCED_ATOMS || airAdded >= 4) {
				break;
			}
			class_2338 pos = anchorBlockPos.method_10069(off.dx(), off.dy(), off.dz());
			String label = formatAtomLabel("Air", ChemistryKind.ATMOSPHERE.formula);
			if (placeNeighborCluster(placed, clusterCenters, off, pos, ChemistryKind.ATMOSPHERE, label)) {
				airAdded++;
			}
		}

		return new SyncedBlockContext(blockName, anchorKind.formula, anchorKind.primaryElement, List.copyOf(placed));
	}

	/**
	 * Maps a single {@link class_2680} (without world neighborhood context) to its signature molecular cluster.
	 */
	public static SyncedBlockContext mapSingleBlock(class_2680 state) {
		ChemistryKind kind = classifyBlockStateOnly(state);
		String blockName = resolveDisplayName(state);
		String label = formatAtomLabel(blockName, kind.formula);
		List<PlacedAtomSpec> placed = new ArrayList<>();
		addPrimaryCluster(placed, kind, new class_243(0.0, 2.5, -22.0), label);
		return new SyncedBlockContext(blockName, kind.formula, kind.primaryElement, List.copyOf(placed));
	}

	/**
	 * Returns the Wikipedia-verified chemical formula label for a given {@link class_2680}.
	 */
	public static String getFormulaForBlock(class_2680 state) {
		return classifyBlockStateOnly(state).formula;
	}

	private static void addPrimaryCluster(
			List<PlacedAtomSpec> out,
			ChemistryKind kind,
			class_243 center,
			String label
	) {
		switch (kind) {
			case WATER -> {
				// Iconic bent 104.5-degree H2O molecule (Oxygen vertex + 2 bonded Hydrogens)
				double bondDist = 17.5;
				double sinHalf = Math.sin(H2O_HALF_ANGLE_RAD);
				double cosHalf = Math.cos(H2O_HALF_ANGLE_RAD);
				addIfRoom(out, new PlacedAtomSpec(center, AtomElement.OXYGEN, 1.40f, label));
				addIfRoom(out, new PlacedAtomSpec(
						center.method_1031(-bondDist * sinHalf, -bondDist * cosHalf * 0.72, bondDist * 0.25),
						AtomElement.HYDROGEN, 0.95f, label));
				addIfRoom(out, new PlacedAtomSpec(
						center.method_1031(bondDist * sinHalf, -bondDist * cosHalf * 0.72, bondDist * 0.25),
						AtomElement.HYDROGEN, 0.95f, label));
			}
			case ORGANIC_CHON -> {
				// Cellulose / Biomolecule CHON cluster (Carbon core surrounded by O, H, N)
				addIfRoom(out, new PlacedAtomSpec(center, AtomElement.CARBON, 1.35f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(18.5, 6.0, -5.0), AtomElement.OXYGEN, 1.15f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(-17.0, 8.5, 4.0), AtomElement.HYDROGEN, 0.92f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(-4.0, -16.5, -6.0), AtomElement.NITROGEN, 1.18f, label));
			}
			case PURE_CARBON -> {
				// Tetrahedral Carbon-12 crystal lattice (diamond / graphite)
				addIfRoom(out, new PlacedAtomSpec(center, AtomElement.CARBON, 1.40f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(16.0, 12.0, -10.0), AtomElement.CARBON, 1.18f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(-16.0, 12.0, 10.0), AtomElement.CARBON, 1.18f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(0.0, -16.5, -12.0), AtomElement.CARBON, 1.18f, label));
			}
			case SILICATE -> {
				// SiO2 tetrahedral silicate unit (Silicon center + 2 bonded Oxygens)
				addIfRoom(out, new PlacedAtomSpec(center, AtomElement.SILICON, 1.42f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(-18.0, 10.0, -4.0), AtomElement.OXYGEN, 1.12f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(18.0, -9.5, -4.0), AtomElement.OXYGEN, 1.12f, label));
			}
			case IRON_METAL -> addMetalLattice(out, AtomElement.IRON, center, label);
			case COPPER_METAL -> addMetalLattice(out, AtomElement.COPPER, center, label);
			case GOLD_METAL -> addMetalLattice(out, AtomElement.GOLD, center, label);
			case CALCIUM_MINERAL -> {
				// CaCO3 / Ca3(PO4)2 mineral cluster
				addIfRoom(out, new PlacedAtomSpec(center, AtomElement.CALCIUM, 1.40f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(18.5, 7.0, -6.0), AtomElement.CARBON, 1.10f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(-18.0, 8.0, 4.0), AtomElement.OXYGEN, 1.12f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(2.0, -17.5, -8.0), AtomElement.PHOSPHORUS, 1.20f, label));
			}
			case MARINE_HALITE -> {
				// NaCl ionic cube + SiO2 coastal sand
				addIfRoom(out, new PlacedAtomSpec(center, AtomElement.SODIUM, 1.32f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(18.0, 2.0, -6.0), AtomElement.CHLORINE, 1.28f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(-18.5, -9.0, -4.0), AtomElement.SILICON, 1.22f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(-4.0, 17.5, -8.0), AtomElement.OXYGEN, 1.05f, label));
			}
			case LUMINESCENT_MINERAL -> {
				addIfRoom(out, new PlacedAtomSpec(center, AtomElement.PHOSPHORUS, 1.38f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(18.5, 7.0, -5.0), AtomElement.SULFUR, 1.25f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(-18.0, -8.0, -5.0), AtomElement.SILICON, 1.22f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(0.0, 17.5, -8.0), AtomElement.OXYGEN, 1.08f, label));
			}
			case VOLCANIC_SILICATE -> {
				addIfRoom(out, new PlacedAtomSpec(center, AtomElement.SILICON, 1.38f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(18.0, 9.0, -5.0), AtomElement.OXYGEN, 1.12f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(-18.5, 6.0, -4.0), AtomElement.IRON, 1.26f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(2.0, -17.5, -7.0), AtomElement.SULFUR, 1.18f, label));
			}
			case ATMOSPHERE -> {
				// Earth Atmosphere: 78% N2, 21% O2 — diatomic N2 and O2 pairs
				// Primary N2 diatomic pair right ahead
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(-7.5, 1.0, 0.0), AtomElement.NITROGEN, 1.22f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(7.5, -1.0, 0.0), AtomElement.NITROGEN, 1.22f, label));
				// Secondary O2 diatomic pair flanking to the right-upper quadrant
				class_243 o2Center = new class_243(34.0, 14.0, -12.0);
				addIfRoom(out, new PlacedAtomSpec(o2Center.method_1031(-7.0, 2.0, 0.0), AtomElement.OXYGEN, 1.18f, label));
				addIfRoom(out, new PlacedAtomSpec(o2Center.method_1031(7.0, -2.0, 0.0), AtomElement.OXYGEN, 1.18f, label));
			}
			case DEFAULT_MINERAL -> {
				addIfRoom(out, new PlacedAtomSpec(center, AtomElement.SILICON, 1.35f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(18.0, 8.0, -4.0), AtomElement.OXYGEN, 1.10f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(-17.5, -8.0, -4.0), AtomElement.IRON, 1.22f, label));
				addIfRoom(out, new PlacedAtomSpec(center.method_1031(0.0, 17.5, -8.0), AtomElement.CALCIUM, 1.18f, label));
			}
		}
	}

	private static void addMetalLattice(
			List<PlacedAtomSpec> out,
			AtomElement metal,
			class_243 center,
			String label
	) {
		addIfRoom(out, new PlacedAtomSpec(center, metal, 1.42f, label));
		addIfRoom(out, new PlacedAtomSpec(center.method_1031(20.0, 9.0, -8.0), metal, 1.24f, label));
		addIfRoom(out, new PlacedAtomSpec(center.method_1031(-20.0, 9.0, -8.0), metal, 1.24f, label));
		addIfRoom(out, new PlacedAtomSpec(center.method_1031(0.0, -19.0, -10.0), metal, 1.24f, label));
	}

	private static boolean placeNeighborCluster(
			List<PlacedAtomSpec> out,
			List<class_243> clusterCenters,
			NeighborOffset off,
			class_2338 worldPos,
			ChemistryKind kind,
			String label
	) {
		long hash = worldPos.method_10063() * 0x9E3779B97F4A7C15L;
		double jx = (((hash) & 0xFF) / 255.0 - 0.5) * 6.0;
		double jy = (((hash >> 8) & 0xFF) / 255.0 - 0.5) * 5.0;
		double jz = (((hash >> 16) & 0xFF) / 255.0 - 0.5) * 6.0;

		class_243 base = new class_243(
				off.dx() * NEIGHBOR_BLOCK_SPACING + jx,
				off.dy() * NEIGHBOR_VERTICAL_SPACING + jy,
				off.dz() * NEIGHBOR_BLOCK_SPACING + jz
		);

		if (base.method_1027() < MIN_SPAWN_CLEARANCE_SQR) {
			return false;
		}
		for (class_243 existing : clusterCenters) {
			if (base.method_1025(existing) < MIN_CLUSTER_SEPARATION_SQR) {
				return false;
			}
		}

		clusterCenters.add(base);

		// Place 1-2 representative atoms for each neighbor block matching its exact chemistry
		switch (kind) {
			case WATER -> {
				addIfRoom(out, new PlacedAtomSpec(base, AtomElement.OXYGEN, 1.15f, label));
				if (out.size() < MAX_SYNCED_ATOMS) {
					double bond = 13.5;
					addIfRoom(out, new PlacedAtomSpec(
							base.method_1031(bond * Math.sin(H2O_HALF_ANGLE_RAD), -bond * Math.cos(H2O_HALF_ANGLE_RAD), 0.0),
							AtomElement.HYDROGEN, 0.85f, label));
				}
			}
			case ATMOSPHERE -> {
				// ~75% N2, ~25% O2 across atmospheric neighbor slots
				boolean isOxygen = ((Math.abs(off.dx() * 3 + off.dy() * 5 + off.dz() * 7)) % 4) == 0;
				AtomElement gas = isOxygen ? AtomElement.OXYGEN : AtomElement.NITROGEN;
				addIfRoom(out, new PlacedAtomSpec(base.method_1031(-6.0, 0.0, 0.0), gas, 1.05f, label));
				addIfRoom(out, new PlacedAtomSpec(base.method_1031(6.0, 0.0, 0.0), gas, 1.05f, label));
			}
			case SILICATE -> {
				addIfRoom(out, new PlacedAtomSpec(base, AtomElement.SILICON, 1.18f, label));
				if (out.size() < MAX_SYNCED_ATOMS && off.manhattan() == 1) {
					addIfRoom(out, new PlacedAtomSpec(base.method_1031(13.0, 6.0, 0.0), AtomElement.OXYGEN, 0.95f, label));
				}
			}
			case ORGANIC_CHON -> {
				AtomElement[] chon = {AtomElement.CARBON, AtomElement.OXYGEN, AtomElement.HYDROGEN, AtomElement.NITROGEN};
				AtomElement chosen = chon[Math.floorMod(off.dx() + off.dy() * 2 + off.dz() * 3, chon.length)];
				addIfRoom(out, new PlacedAtomSpec(base, chosen, 1.12f, label));
			}
			case CALCIUM_MINERAL -> {
				AtomElement[] elems = {AtomElement.CALCIUM, AtomElement.CARBON, AtomElement.OXYGEN, AtomElement.PHOSPHORUS};
				AtomElement chosen = elems[Math.floorMod(off.dx() + off.dy() * 3 + off.dz(), elems.length)];
				addIfRoom(out, new PlacedAtomSpec(base, chosen, 1.15f, label));
			}
			case MARINE_HALITE -> {
				boolean isCl = Math.floorMod(off.dx() + off.dy() + off.dz(), 2) == 0;
				addIfRoom(out, new PlacedAtomSpec(base, isCl ? AtomElement.CHLORINE : AtomElement.SODIUM, 1.12f, label));
			}
			case LUMINESCENT_MINERAL -> {
				boolean isS = Math.floorMod(off.dx() + off.dz(), 2) == 0;
				addIfRoom(out, new PlacedAtomSpec(base, isS ? AtomElement.SULFUR : AtomElement.PHOSPHORUS, 1.15f, label));
			}
			case VOLCANIC_SILICATE -> {
				AtomElement[] elems = {AtomElement.SILICON, AtomElement.IRON, AtomElement.SULFUR, AtomElement.OXYGEN};
				AtomElement chosen = elems[Math.floorMod(off.dx() * 2 + off.dy() + off.dz(), elems.length)];
				addIfRoom(out, new PlacedAtomSpec(base, chosen, 1.16f, label));
			}
			default -> addIfRoom(out, new PlacedAtomSpec(base, kind.primaryElement, 1.18f, label));
		}
		return true;
	}

	private static void addIfRoom(List<PlacedAtomSpec> list, PlacedAtomSpec spec) {
		if (list.size() < MAX_SYNCED_ATOMS) {
			list.add(spec);
		}
	}

	private static ChemistryKind classifyBlock(class_3218 overworld, class_2338 pos, class_2680 state) {
		// Sand directly bordering water exhibits coastal halite (NaCl + SiO2) chemistry
		if (state.method_26164(class_3481.field_15466) && isAdjacentToWater(overworld, pos)) {
			return ChemistryKind.MARINE_HALITE;
		}
		return classifyBlockStateOnly(state);
	}

	private static boolean isAdjacentToWater(class_3218 overworld, class_2338 pos) {
		for (class_2350 dir : class_2350.values()) {
			if (overworld.method_8316(pos.method_10093(dir)).method_15767(class_3486.field_15517)) {
				return true;
			}
		}
		return false;
	}

	private static ChemistryKind classifyBlockStateOnly(class_2680 state) {
		if (state == null || (state.method_26215() && state.method_26227().method_15769())) {
			return ChemistryKind.ATMOSPHERE;
		}

		class_2248 block = state.method_26204();
		String path = class_7923.field_41175.method_10221(block).method_12832().toLowerCase(Locale.ROOT);

		// 1. Water / Ice / Snow -> H2O
		if (state.method_26227().method_15767(class_3486.field_15517)
				|| state.method_26164(class_3481.field_15467)
				|| state.method_26164(class_3481.field_29823)
				|| block == class_2246.field_10382
				|| block == class_2246.field_10422
				|| path.contains("water")
				|| path.contains("ice")
				|| path.contains("snow")) {
			return ChemistryKind.WATER;
		}

		// 2. Pure Carbon (Coal / Diamond)
		if (state.method_26164(class_3481.field_29193)
				|| state.method_26164(class_3481.field_28989)
				|| block == class_2246.field_10381
				|| block == class_2246.field_10201
				|| path.contains("coal")
				|| path.contains("diamond")) {
			return ChemistryKind.PURE_CARBON;
		}

		// 3. Metals (Iron, Copper, Gold)
		if (state.method_26164(class_3481.field_28988)
				|| block == class_2246.field_10085
				|| block == class_2246.field_33508
				|| block == class_2246.field_10535
				|| block == class_2246.field_10105
				|| block == class_2246.field_10414
				|| block == class_2246.field_10593
				|| block == class_2246.field_10312
				|| block == class_2246.field_23985
				|| block == class_2246.field_16333
				|| path.contains("iron")
				|| path.contains("anvil")
				|| path.contains("cauldron")
				|| path.contains("rail")) {
			return ChemistryKind.IRON_METAL;
		}
		if (state.method_26164(class_3481.field_29195)
				|| block == class_2246.field_27119
				|| block == class_2246.field_33509
				|| block == class_2246.field_27171
				|| path.contains("copper")) {
			return ChemistryKind.COPPER_METAL;
		}
		if (state.method_26164(class_3481.field_23062)
				|| block == class_2246.field_10205
				|| block == class_2246.field_33510
				|| block == class_2246.field_23880
				|| block == class_2246.field_16332
				|| path.contains("gold")) {
			return ChemistryKind.GOLD_METAL;
		}

		// 4. Calcium minerals (Bone / Calcite / Dripstone / Coral)
		if (block == class_2246.field_10166
				|| block == class_2246.field_27114
				|| block == class_2246.field_28049
				|| block == class_2246.field_28048
				|| state.method_26164(class_3481.field_15488)
				|| state.method_26164(class_3481.field_15476)
				|| path.contains("bone")
				|| path.contains("calcite")
				|| path.contains("dripstone")
				|| path.contains("coral")) {
			return ChemistryKind.CALCIUM_MINERAL;
		}

		// 5. Marine Halite (Prismarine / Sponge)
		if (path.contains("prismarine") || path.contains("sponge")) {
			return ChemistryKind.MARINE_HALITE;
		}

		// 6. Luminescent minerals (Redstone / Glowstone / Lanterns)
		if (state.method_26164(class_3481.field_28990)
				|| block == class_2246.field_10002
				|| block == class_2246.field_10091
				|| block == class_2246.field_10171
				|| block == class_2246.field_10174
				|| block == class_2246.field_22122
				|| path.contains("redstone")
				|| path.contains("glowstone")
				|| path.contains("froglight")) {
			return ChemistryKind.LUMINESCENT_MINERAL;
		}

		// 7. Organic CHON (Wood / Leaves / Grass / Plants / Wool / Crops)
		if (state.method_26164(class_3481.field_15475)
				|| state.method_26164(class_3481.field_15471)
				|| state.method_26164(class_3481.field_15503)
				|| state.method_26164(class_3481.field_20339)
				|| state.method_26164(class_3481.field_15462)
				|| state.method_26164(class_3481.field_15481)
				|| state.method_26164(class_3481.field_15479)
				|| state.method_26164(class_3481.field_20341)
				|| block == class_2246.field_10219
				|| block == class_2246.field_10479
				|| block == class_2246.field_10214
				|| block == class_2246.field_10112
				|| block == class_2246.field_10313
				|| block == class_2246.field_28681
				|| block == class_2246.field_28680
				|| block == class_2246.field_10597
				|| block == class_2246.field_10359
				|| block == class_2246.field_10211
				|| block == class_2246.field_10029
				|| block == class_2246.field_10424
				|| block == class_2246.field_46282
				|| block == class_2246.field_46283
				|| block == class_2246.field_9993
				|| block == class_2246.field_10463
				|| block == class_2246.field_10376
				|| block == class_2246.field_10238
				|| path.contains("log")
				|| path.contains("wood")
				|| path.contains("plank")
				|| path.contains("leaves")
				|| path.contains("grass")
				|| path.contains("moss")
				|| path.contains("vine")
				|| path.contains("flower")
				|| path.contains("fern")
				|| path.contains("sapling")
				|| path.contains("wool")
				|| path.contains("carpet")
				|| path.contains("bamboo")
				|| path.contains("cactus")
				|| path.contains("mushroom")
				|| path.contains("fungus")
				|| path.contains("stem")
				|| path.contains("hyphae")
				|| path.contains("pumpkin")
				|| path.contains("melon")
				|| path.contains("hay")
				|| path.contains("chest")
				|| path.contains("barrel")
				|| path.contains("bookshelf")
				|| path.contains("crafting_table")) {
			return ChemistryKind.ORGANIC_CHON;
		}

		// 8. Volcanic / Nether silicates (Obsidian / Netherrack / Basalt / Blackstone / Magma)
		if (block == class_2246.field_10540
				|| block == class_2246.field_22423
				|| block == class_2246.field_22091
				|| block == class_2246.field_23151
				|| block == class_2246.field_29032
				|| block == class_2246.field_23869
				|| block == class_2246.field_10515
				|| block == class_2246.field_10092
				|| block == class_2246.field_10114
				|| block == class_2246.field_22090
				|| state.method_26164(class_3481.field_25807)
				|| path.contains("obsidian")
				|| path.contains("basalt")
				|| path.contains("blackstone")
				|| path.contains("nether")
				|| path.contains("magma")
				|| path.contains("soul_")) {
			return ChemistryKind.VOLCANIC_SILICATE;
		}

		// 9. Silicates (Stone / Cobblestone / Deepslate / Sand / Glass / Quartz / Dirt / Clay)
		if (state.method_26164(class_3481.field_25806)
				|| state.method_26164(class_3481.field_15465)
				|| state.method_26164(class_3481.field_15466)
				|| state.method_26164(class_3481.field_29822)
				|| state.method_26164(class_3481.field_36265)
				|| state.method_26164(class_3481.field_15490)
				|| block == class_2246.field_10445
				|| block == class_2246.field_9989
				|| block == class_2246.field_10360
				|| block == class_2246.field_10255
				|| block == class_2246.field_10460
				|| block == class_2246.field_37576
				|| block == class_2246.field_9979
				|| block == class_2246.field_10344
				|| block == class_2246.field_10153
				|| path.contains("stone")
				|| path.contains("deepslate")
				|| path.contains("granite")
				|| path.contains("diorite")
				|| path.contains("andesite")
				|| path.contains("tuff")
				|| path.contains("sand")
				|| path.contains("glass")
				|| path.contains("quartz")
				|| path.contains("gravel")
				|| path.contains("dirt")
				|| path.contains("mud")
				|| path.contains("clay")
				|| path.contains("terracotta")
				|| path.contains("concrete")
				|| path.contains("brick")
				|| path.contains("cobble")) {
			return ChemistryKind.SILICATE;
		}

		return ChemistryKind.DEFAULT_MINERAL;
	}

	private static String resolveDisplayName(class_2680 state) {
		if (state == null || (state.method_26215() && state.method_26227().method_15769())) {
			return "Air";
		}
		if (state.method_26227().method_15767(class_3486.field_15517) && state.method_26215()) {
			return "Water";
		}
		String translated = state.method_26204().method_9518().getString();
		if (translated != null && !translated.isBlank() && !translated.startsWith("block.")) {
			return translated;
		}
		// Clean fallback formatting from registry path (e.g., "oak_log" -> "Oak Log")
		String path = class_7923.field_41175.method_10221(state.method_26204()).method_12832();
		String[] parts = path.split("_");
		StringBuilder sb = new StringBuilder();
		for (String part : parts) {
			if (part.isEmpty()) {
				continue;
			}
			if (!sb.isEmpty()) {
				sb.append(' ');
			}
			sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
		}
		return sb.isEmpty() ? "Block" : sb.toString();
	}

	private static String formatAtomLabel(String blockName, String formula) {
		return blockName + " — " + formula;
	}

	private static List<NeighborOffset> buildOrderedNeighborOffsets() {
		List<NeighborOffset> offsets = new ArrayList<>(26);
		for (int dx = -1; dx <= 1; dx++) {
			for (int dy = -1; dy <= 1; dy++) {
				for (int dz = -1; dz <= 1; dz++) {
					if (dx == 0 && dy == 0 && dz == 0) {
						continue;
					}
					offsets.add(new NeighborOffset(dx, dy, dz));
				}
			}
		}
		offsets.sort(Comparator.comparingInt(NeighborOffset::manhattan)
				.thenComparingInt(o -> Math.abs(o.dy()))
				.thenComparingInt(NeighborOffset::dx)
				.thenComparingInt(NeighborOffset::dz));
		return List.copyOf(offsets);
	}
}

package com.quantumatom.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.quantumatom.QuantumAtomMod;
import com.quantumatom.dimension.QuantumRealmDimension;
import com.quantumatom.dimension.QuantumRealmDimension.ScaleLayer;
import com.quantumatom.entity.AtomEntity;
import com.quantumatom.entity.AtomEntity.RenderMode;
import com.quantumatom.portal.QuantumPortalManager;
import com.quantumatom.scale.ScaleManager;
import com.quantumatom.science.AtomElement;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public final class AtomCommand {
	private static final SuggestionProvider<class_2168> ELEMENT_SUGGESTIONS = (ctx, builder) ->
			class_2172.method_9264(
					Arrays.stream(AtomElement.values())
							.map(e -> e.name().toLowerCase(Locale.ROOT)),
					builder
			);

	private AtomCommand() {
	}

	public static void register(CommandDispatcher<class_2168> dispatcher) {
		dispatcher.register(class_2170.method_9247("atom")
				.then(class_2170.method_9247("shrinker")
						.executes(ctx -> giveShrinker(ctx.getSource()))
				)
				.then(class_2170.method_9247("dive")
						.executes(ctx -> diveDeeper(ctx.getSource()))
				)
				.then(class_2170.method_9247("ascend")
						.executes(ctx -> ascendUp(ctx.getSource()))
				)
				.then(class_2170.method_9247("spawn")
						.then(class_2170.method_9244("element", StringArgumentType.word())
								.suggests(ELEMENT_SUGGESTIONS)
								.executes(ctx -> spawnAtom(
										ctx.getSource(),
										StringArgumentType.getString(ctx, "element"),
										1.5f
								))
								.then(class_2170.method_9244("size", FloatArgumentType.floatArg(0.25f, 4.0f))
										.executes(ctx -> spawnAtom(
												ctx.getSource(),
												StringArgumentType.getString(ctx, "element"),
												FloatArgumentType.getFloat(ctx, "size")
										))
								)
						)
				)
				.then(class_2170.method_9247("scale")
						.then(class_2170.method_9244("value", DoubleArgumentType.doubleArg(ScaleManager.MIN_SCALE, ScaleManager.MAX_SCALE))
								.executes(ctx -> setPlayerScale(
										ctx.getSource(),
										DoubleArgumentType.getDouble(ctx, "value")
								))
						)
				)
				.then(class_2170.method_9247("clear")
						.executes(ctx -> clearAtoms(ctx.getSource()))
				)
		);
	}

	private static int diveDeeper(class_2168 source) {
		if (!(source.method_9228() instanceof class_3222 player)) {
			source.method_9213(class_2561.method_43470("This command must be run by a player."));
			return 0;
		}
		if (QuantumPortalManager.isTransitioning(player.method_5667())) {
			source.method_9213(class_2561.method_43470("Quantum zoom transition already in progress."));
			return 0;
		}
		boolean started = QuantumPortalManager.startDiveTransition(player);
		if (!started) {
			return 0;
		}
		source.method_9226(() -> class_2561.method_43470("Initiated seamless shrink dive to deeper subatomic layer."), false);
		return 1;
	}

	private static int ascendUp(class_2168 source) {
		if (!(source.method_9228() instanceof class_3222 player)) {
			source.method_9213(class_2561.method_43470("This command must be run by a player."));
			return 0;
		}
		if (QuantumPortalManager.isTransitioning(player.method_5667())) {
			source.method_9213(class_2561.method_43470("Quantum zoom transition already in progress."));
			return 0;
		}
		boolean started = QuantumPortalManager.startAscendTransition(player);
		if (!started) {
			return 0;
		}
		source.method_9226(() -> class_2561.method_43470("Initiated seamless grow-out ascent to shallower scale layer."), false);
		return 1;
	}

	private static int spawnAtom(class_2168 source, String elementName, float size) {
		Optional<AtomElement> elementOpt = AtomElement.fromName(elementName);
		if (elementOpt.isEmpty()) {
			String available = String.join(", ",
					Arrays.stream(AtomElement.values())
							.map(e -> e.name().toLowerCase(Locale.ROOT))
							.toList());
			source.method_9213(class_2561.method_43470("Unknown element: " + elementName + ". Available: " + available));
			return 0;
		}

		AtomElement element = elementOpt.get();
		ScaleLayer layer = QuantumRealmDimension.getLayer(source.method_9225());
		RenderMode renderMode = switch (layer) {
			case NUCLEAR -> RenderMode.NUCLEUS_ONLY;
			case QUARK -> RenderMode.QUARK_INTERIOR;
			case OVERWORLD, ATOMIC -> RenderMode.ATOMIC_CLOUD;
		};

		class_243 spawnPos = source.method_9222().method_1031(0.0, 14.0 * size, 0.0);
		if (source.method_9228() instanceof class_3222 player) {
			class_243 look = player.method_5720();
			double forwardDist = renderMode == RenderMode.QUARK_INTERIOR ? 0.0 : 18.0 * size;
			spawnPos = player.method_33571().method_1019(look.method_1021(forwardDist));
		}

		AtomEntity atom = new AtomEntity(QuantumAtomMod.ATOM_ENTITY, source.method_9225());
		atom.method_5814(spawnPos.field_1352, spawnPos.field_1351, spawnPos.field_1350);
		atom.setElement(element);
		atom.setAtomScale(size);
		atom.setRenderMode(renderMode);
		atom.setSourceLabel(element.isotopeName());
		source.method_9225().method_8649(atom);

		source.method_9226(() -> class_2561.method_43470(
				String.format("Spawned %s (%s) [%s | %dp+, %dn0, %s, scale=%.2f] at (%.1f, %.1f, %.1f)",
						element.isotopeName(), element.symbol(), renderMode.name(),
						element.protons(), element.neutrons(), element.electronConfig(),
						size, atom.method_23317(), atom.method_23318(), atom.method_23321())
		), true);
		return 1;
	}

	private static int clearAtoms(class_2168 source) {
		class_243 pos = source.method_9222();
		class_238 box = class_238.method_30048(pos, 320.0, 320.0, 320.0);
		List<AtomEntity> atoms = source.method_9225().method_18467(AtomEntity.class, box);
		atoms.forEach(AtomEntity::method_31472);
		int count = atoms.size();
		source.method_9226(() -> class_2561.method_43470("Removed " + count + " subatomic entity/entities."), true);
		return count;
	}

	private static int setPlayerScale(class_2168 source, double scale) {
		if (!(source.method_9228() instanceof class_3222 player)) {
			source.method_9213(class_2561.method_43470("This command must be run by a player."));
			return 0;
		}
		if (QuantumPortalManager.isTransitioning(player.method_5667())) {
			source.method_9213(class_2561.method_43470("Cannot change scale mid-transition."));
			return 0;
		}

		ScaleLayer layer = QuantumRealmDimension.getLayer(player.method_37908());
		if (scale < ScaleManager.SHRINK_DIVE_THRESHOLD && layer != ScaleLayer.QUARK) {
			ScaleManager.setScale(player, scale);
			source.method_9226(() -> class_2561.method_43470(
					String.format("Shrinking to %.4fx — crossing %.2fx will dive seamlessly into %s!",
							scale, ScaleManager.SHRINK_DIVE_THRESHOLD, layer.deeper().displayName())
			), false);
			return 1;
		}
		if (scale > ScaleManager.GROW_ASCEND_THRESHOLD && layer != ScaleLayer.OVERWORLD) {
			ScaleManager.setScale(player, scale);
			source.method_9226(() -> class_2561.method_43470(
					String.format("Growing to %.4fx — crossing %.2fx will ascend seamlessly to %s!",
							scale, ScaleManager.GROW_ASCEND_THRESHOLD, layer.shallower().displayName())
			), false);
			return 1;
		}

		if (layer == ScaleLayer.OVERWORLD && Math.abs(scale - 1.0) < 0.01) {
			ScaleManager.resetToMacroscopic(player);
		} else {
			ScaleManager.setScale(player, scale);
		}
		source.method_9226(() -> class_2561.method_43470(
				String.format("Set scale to %.4fx (%s)", scale, ScaleManager.describeScale(scale))
		), false);
		return 1;
	}

	private static int giveShrinker(class_2168 source) {
		if (!(source.method_9228() instanceof class_3222 player)) {
			source.method_9213(class_2561.method_43470("This command must be run by a player."));
			return 0;
		}
		player.method_31548().method_7394(new class_1799(QuantumAtomMod.QUANTUM_SHRINKER));
		source.method_9226(() -> class_2561.method_43470(
				"Given Quantum Shrinker! Right-Click to shrink deeper (Overworld -> Atomic -> Nuclear -> Quark); Shift+Right-Click to grow back up."
		), false);
		return 1;
	}
}

package com.quantumatom.network;

import com.quantumatom.QuantumAtomMod;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * S2C payload triggered when a player begins a seamless multi-dimension quantum zoom transition
 * (shrinking deeper or growing back up). The client uses this payload to drive the smooth
 * pre-swap windup (FOV stretch + radial speed-lines + woosh), transition apex flash at
 * {@code swapTick}, post-swap arrival ease-out through {@code durationTicks}, and HUD synced
 * Overworld block/chemistry context.
 */
public record ZoomEffectPayload(
		boolean shrinkingIn,
		int targetLayerOrdinal,
		int durationTicks,
		int swapTick,
		String blockLabel,
		String chemicalFormula
) implements class_8710 {
	public static final class_8710.class_9154<ZoomEffectPayload> TYPE =
			new class_8710.class_9154<>(QuantumAtomMod.id("zoom_effect"));

	public static final class_9139<class_9129, ZoomEffectPayload> STREAM_CODEC =
			class_8710.method_56484(ZoomEffectPayload::write, ZoomEffectPayload::read);

	public ZoomEffectPayload {
		blockLabel = blockLabel != null ? blockLabel : "";
		chemicalFormula = chemicalFormula != null ? chemicalFormula : "";
	}

	private void write(class_9129 buf) {
		buf.method_52964(this.shrinkingIn);
		buf.method_10804(this.targetLayerOrdinal);
		buf.method_10804(this.durationTicks);
		buf.method_10804(this.swapTick);
		buf.method_10788(this.blockLabel, 256);
		buf.method_10788(this.chemicalFormula, 256);
	}

	private static ZoomEffectPayload read(class_9129 buf) {
		boolean shrinkingIn = buf.readBoolean();
		int targetLayerOrdinal = buf.method_10816();
		int durationTicks = buf.method_10816();
		int swapTick = buf.method_10816();
		String blockLabel = buf.method_10800(256);
		String chemicalFormula = buf.method_10800(256);
		return new ZoomEffectPayload(
				shrinkingIn,
				targetLayerOrdinal,
				durationTicks,
				swapTick,
				blockLabel,
				chemicalFormula
		);
	}

	@Override
	public class_9154<? extends class_8710> method_56479() {
		return TYPE;
	}
}

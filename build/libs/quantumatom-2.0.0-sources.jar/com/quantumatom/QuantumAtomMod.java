package com.quantumatom;

import com.quantumatom.command.AtomCommand;
import com.quantumatom.dimension.QuantumRealmDimension;
import com.quantumatom.entity.AtomEntity;
import com.quantumatom.item.QuantumShrinkerItem;
import com.quantumatom.network.ZoomEffectPayload;
import com.quantumatom.portal.QuantumPortalManager;
import com.quantumatom.scale.ScaleManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class QuantumAtomMod implements ModInitializer {
	public static final String MOD_ID = "quantumatom";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static final class_1299<AtomEntity> ATOM_ENTITY = class_2378.method_10230(
			class_7923.field_41177,
			id("atom"),
			class_1299.class_1300.<AtomEntity>method_5903(AtomEntity::new, class_1311.field_17715)
					.method_17687(0.5f, 0.5f)
					.method_27299(16)
					.method_27300(10)
					.build()
	);

	public static final class_1792 QUANTUM_SHRINKER = class_2378.method_10230(
			class_7923.field_41178,
			id("quantum_shrinker"),
			new QuantumShrinkerItem(new class_1792.class_1793().method_7889(1))
	);

	@Override
	public void onInitialize() {
		PayloadTypeRegistry.playS2C().register(ZoomEffectPayload.TYPE, ZoomEffectPayload.STREAM_CODEC);

		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				AtomCommand.register(dispatcher)
		);

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			QuantumPortalManager.tickServer(server);
			ScaleManager.tickServer(server);
			QuantumRealmDimension.tickServer(server);
		});

		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
			QuantumPortalManager.onPlayerDisconnect(handler.field_14140);
			ScaleManager.onPlayerDisconnect(handler.field_14140);
			QuantumRealmDimension.onPlayerDisconnect(handler.field_14140);
		});

		ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries ->
				entries.method_45421(QUANTUM_SHRINKER)
		);

		LOGGER.info("Quantum Atom Explorer initialized (4-Tier Seamless Subatomic Zoom: Overworld <-> Atomic <-> Nuclear <-> Quark).");
	}

	public static class_2960 id(String path) {
		return class_2960.method_60655(MOD_ID, path);
	}
}
